from pygame import *
import sys
from pygame.locals import QUIT


# time
clock = time.Clock()
 

#correr
perso = image.load('Run.png')
frame = 0
time_frame = 0
perso_invert = transform.flip(perso,True,False)
run = True

#personagem geral
pos_x = 0
estado_pers = perso
pos_y = 500

#atacar
attack = image.load('Attack_3.png')
time_frame_attack = 0
frame_attack = 0
attaca_inv = transform.flip(attack,True,False)
attacks = False


#o mapa 
mapa = open('Mapa.txt','r')


# Tamanho dos tiles e tela
tile_size = 32
screen = display.set_mode((1536, 800))

#variaveis para a agua
frame_a = 1
time_frame_a = 0


# Carrega e prepara o tileset
tile_set = image.load('sprite_jogo_tiles.png')
tile_set = transform.scale(tile_set, (416,32))

#listas para o mapa(lista que vem de um arquivo) e para a colisao da agua(tem uma animacao)
agua_rects = []
real_map = []
colide_caixa = []
            

# Loop principal
while True:
    for ev in event.get():
        if ev.type == QUIT:
            quit()
            sys.exit()
            #volta ao sprite original ao soltar o botão
        if ev.type == KEYUP:
            if ev.key == K_d:
                frame = 0
                time_fram = 0
            if ev.key == K_a:
                frame = 0
                time_fram = 0
                
        #botoes de ataque      
        if ev.type == KEYDOWN:
            if ev.key == K_e:
                attacks = True
    
    #pega as teclas do teclado            
    keys = key.get_pressed()
    

    antigo_x = pos_x
    antigo_y = pos_y

    
    aparece_mapa = {'G': (0,0,32,32),
                    'A': (32*(frame_a%10),32*(frame_a//10),32,32),
                    'M': (320,0,32,32),
                    'B': (352,0,32,32),
                    }


    
    for l in mapa:
        l = l.strip()
        print(l)
        real_map.append(l)
    
    #mapa aparecendo    
    for i in range(len(real_map)):
        for j in range(len(real_map[i])): 
            screen.blit(tile_set, (j * tile_size ,i * tile_size ,tile_size,tile_size),(aparece_mapa[real_map[i][j]]))
            if real_map[i][j] == 'B':
                colide_caixa.append(Rect(j * tile_size, i * tile_size, tile_size, tile_size))
    
        
    #colisao da agua        
    for i in range(len(real_map)):
        for j in range(len(real_map[i])):
            if real_map[i][j] == 'A':
                agua_rects.append(Rect(j * tile_size, i * tile_size, tile_size, tile_size))
            
        
    #AGUA CORRENDO        
    clock.tick(60)
    dt = clock.get_time()               
    time_frame_a += dt
    if time_frame_a > 150:
        frame_a += 1
        time_frame_a = 0
    if frame_a >= 10:
        frame_a = 1
        
        
        
    #correr,atacar e pular
    if run == True: 
        screen.blit(perso, (pos_x,pos_y), (128*(frame%8),128*(frame//8),128,128))
    if attacks == True:
        screen.blit(estado_pers, (pos_x,pos_y), (128*(frame_attack%4),128*(frame_attack//4),128,128))
        
    #andar direita
    if keys[K_d]:
        perso = image.load('Run.png')
        pos_x = pos_x + 0.3*dt
        time_frame += dt
        if time_frame > 150:
            frame += 1
            time_frame = 0
        if frame >= 8:
            frame = 0
            
    #andar esquerda           
    if keys[K_a]:
        perso = perso_invert
        pos_x = pos_x - 0.3*dt
        time_frame += dt
        if time_frame > 150:
            frame += 1
            time_frame = 0
        if frame >= 8:
            frame = 0
        if attacks == True:
            attack = attaca_inv
        

    #andar esquerda           
    if keys[K_w]:
        #perso = perso_invert
        pos_y = pos_y - 0.3*dt
        time_frame += dt
        if time_frame > 150:
            frame += 1
            time_frame = 0
        if frame >= 8:
            frame = 0
        if attacks == True:
            attack = attaca_inv
            
            
    #andar esquerda           
    if keys[K_s]:
        #perso = perso_invert
        pos_y = pos_y + 0.3*dt
        time_frame += dt
        if time_frame > 150:
            frame += 1
            time_frame = 0
        if frame >= 8:
            frame = 0
        if attacks == True:
            attack = attaca_inv
            
    #ataque
    if attacks == True:
        run = False
        estado_pers = attack
        if not keys[K_a]:
            attack = image.load('Attack_3.png')
        time_frame_attack += dt/1.5
        if time_frame_attack > 150:
            frame_attack += 1
            time_frame_attack = 0
        if frame_attack >= 4:
            frame_attack = 0
            estado_pers = perso
            run = True
            attacks = False
   
    #colisão
    coli_pers = Rect(pos_x + 35, pos_y + 100, 38, 28)

    #se colisao com agua
    if coli_pers.collidelist(agua_rects) != -1:
        pos_x = antigo_x
        pos_y = antigo_y
        
    #se colisao com caixa:
    if coli_pers.collidelist(colide_caixa) != -1:
        pos_x = antigo_x
        pos_y = antigo_y
        
        
 

    
    display.update()
